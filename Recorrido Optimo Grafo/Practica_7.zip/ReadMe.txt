El programa se compila con el comando >python main.py
La matriz de adyasencia se define en el archivo matriz.txt

El programa va a preguntar al usuario de que nodo quiere partir el recorrido
El programa imprime la ruta a tomar y el costo total del viaje 